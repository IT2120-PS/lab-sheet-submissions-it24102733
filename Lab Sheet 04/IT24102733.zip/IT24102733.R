setwd("C:\\Users\\it24102733\\Desktop\\it24102733-Lab-04")


getwd()
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

check_variable <- function(x) {
  if (is.numeric(x)) {
    return("Numeric (Ratio Scale)")
  } else if (is.factor(x) || is.character(x)) {
    return("Categorical (Nominal Scale)")
  } else {
    return("other")
  }
}

sapply(branch_data, check_variable)

boxplot(branch_data$Sales_X1,
        main = "Box plot for Sales",
        outline = TRUE,
        outpch = 8,
        horizontal = TRUE)




summary(branch_data$Branch)

summary(branch_data$Sales_X1)

summary(branch_data$Advertising_X2)


summary(branch_data$Years_X3)

IQR(branch_data$Sales_X1)
IQR(branch_data$Advertising_X2)
IQR(branch_data$Years_X3)
# Branch data analysis code

# Summary statistics for Branch data
summary(branch_data$Branch)

# Summary statistics for Sales (X1)
summary(branch_data$Sales_X1)

# Summary statistics for Advertising (X2)
summary(branch_data$Advertising_X2)

# Summary statistics for Years (X3)
summary(branch_data$Years_X3)

# IQR calculations
IQR(branch_data$Sales_X1)
IQR(branch_data$Advertising_X2)
IQR(branch_data$Years_X3)

# Outlier detection using get.outliers function (built-in)
get.outliers(branch_data$Branch)
get.outliers(branch_data$Sales_X1)
get.outliers(branch_data$Advertising_X2)
get.outliers(branch_data$Years_X3)

# Custom outlier detection function
get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper bound =", ub))
  print(paste("Lower bound =", lb))
  print(paste("Outliers =", paste(sort(z[z > ub | z < ub]), collapse = ", ")))
}

# Apply custom function to detect outliers
get.outliers(branch_data$Branch)
get.outliers(branch_data$Sales_X1)
get.outliers(branch_data$Advertising_X2)
get.outliers(branch_data$Years_X3)
